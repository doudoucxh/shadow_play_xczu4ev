"""Bounded startup recovery. Do not ignore DMA failures or restart forever."""
import mmap
import os
from pathlib import Path
import signal
import struct
import subprocess
import sys
import time

STOPPING = False
CHILD = None

def stop(signum, _):
    global STOPPING
    STOPPING = True
    if CHILD is not None and CHILD.poll() is None:
        CHILD.send_signal(signum)

def settle(min_uptime=30):
    while not STOPPING:
        uptime = float(Path('/proc/uptime').read_text().split()[0])
        if uptime >= min_uptime:
            return
        time.sleep(min(.2, min_uptime-uptime))
    raise InterruptedError('Stopping during startup')

def run(command, timeout=None):
    global CHILD
    if STOPPING:
        raise InterruptedError('Stopping')
    CHILD = subprocess.Popen(command)
    try:
        return CHILD.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        CHILD.terminate()
        try:
            CHILD.wait(timeout=3)
        except subprocess.TimeoutExpired:
            CHILD.kill()
            CHILD.wait()
        raise
    finally:
        CHILD = None

def shared_ring():
    fd = os.open('/dev/mem', os.O_RDONLY | os.O_SYNC)
    try:
        with mmap.mmap(fd, 65536, prot=mmap.PROT_READ, offset=0xA0000000) as regs:
            addresses = [struct.unpack_from('<I', regs, off)[0] for off in (0x5c,0x60,0x64)]
            return addresses == [0x70000000,0x702a3000,0x70546000]
    finally:
        os.close(fd)

def stable_video(seconds=3):
    fd = os.open('/dev/mem', os.O_RDONLY | os.O_SYNC)
    try:
        with mmap.mmap(fd,65536,prot=mmap.PROT_READ,offset=0xA0000000) as v, \
             mmap.mmap(fd,65536,prot=mmap.PROT_READ,offset=0xA0010000) as p:
            rd = lambda m,o: struct.unpack_from('<I',m,o)[0]
            previous = (rd(v,0x28)>>24)&31
            frames = 0
            start = time.monotonic()
            while time.monotonic()-start < seconds:
                if STOPPING:
                    raise InterruptedError('Stopping')
                states = rd(v,4),rd(v,0x34),rd(p,0x34)
                if any(x&0x8ff1 for x in states):
                    raise RuntimeError('Startup DMA status: '+str([hex(x) for x in states]))
                current = (rd(v,0x28)>>24)&31
                if current > 2:
                    raise RuntimeError('Invalid capture index')
                if current != previous:
                    frames += 1
                    previous = current
                time.sleep(.002)
            if frames < seconds*20:
                raise RuntimeError('Insufficient stable camera frames: '+str(frames))
            print('FOLLOW_BOOT_VIDEO_STABLE frames='+str(frames),flush=True)
    finally:
        os.close(fd)

def video():
    settle()
    for attempt in range(2):
        if STOPPING:
            return 1
        print('FOLLOW_BOOT_VIDEO_INIT attempt='+str(attempt+1),flush=True)
        try:
            if run(['/usr/bin/shadow-video-init'],timeout=35) != 0:
                raise RuntimeError('Video initializer failed')
            stable_video()
            return 0
        except (RuntimeError,subprocess.TimeoutExpired) as exc:
            print('FOLLOW_BOOT_VIDEO_FAILURE '+str(exc),flush=True)
            # No retry after a hung initializer: termination may leave registers mid-write.
            if isinstance(exc,subprocess.TimeoutExpired) or attempt == 1:
                return 1
            time.sleep(2)
    return 1

def retry_early_dma(code, seconds, text, stopping):
    return (code != 0 and seconds < 20 and not stopping and
            any(marker in text for marker in ('Camera DMA error','Video DMA error','Pose drain DMA error')))

def follow():
    global CHILD
    for attempt in range(2):
        if STOPPING:
            return 0
        recent = []
        start = time.monotonic()
        CHILD = subprocess.Popen(['/usr/bin/python3','-u',str(Path(__file__).with_name('board_follow.py'))],
                                 stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        try:
            for line in CHILD.stdout:
                print(line,end='',flush=True)
                recent.append(line)
                recent = recent[-60:]
            code = CHILD.wait()
        finally:
            CHILD.stdout.close()
            CHILD = None
        if attempt or not retry_early_dma(code,time.monotonic()-start,''.join(recent),STOPPING):
            return code
        if not shared_ring():
            print('FOLLOW_BOOT_RECOVERY_REFUSED display_not_restored',flush=True)
            return code
        print('FOLLOW_BOOT_ONE_EARLY_DMA_RECOVERY',flush=True)
        # Child has exited and released its resources; never reinitialize under live inference.
        if video() != 0:
            return 1
    return 1

def main():
    signal.signal(signal.SIGTERM,stop)
    signal.signal(signal.SIGINT,stop)
    mode = sys.argv[1] if len(sys.argv)==2 else ''
    if mode not in ('video','follow'):
        raise SystemExit('Expected video or follow')
    try:
        return video() if mode=='video' else follow()
    except InterruptedError:
        return 0 if STOPPING else 1

if __name__=='__main__':
    sys.exit(main())
